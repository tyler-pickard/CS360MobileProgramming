package com.example.tyler_pickard_o3_weight_tracker_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }






}//end of Main class

//SQ Lite setup

String Database Name = "weightEntries.db";
private static final class WeightTable {
    private static final String Table = "weight";
    private static final String Id = "id";
    private static final String columnTitle = "Weight";
    private static final String RowTitle = "data";
}
@Override
public void onCreate(SQLiteDatabase db){
    db.execSQL("create table " + WeightTable.Table+ "(" +
            WeightTable.Id + "integer primary key autoincrement, " +
            WeightTable.columnTitle + "text" +
            WeightTable.RowTitle + " text"
    );
};